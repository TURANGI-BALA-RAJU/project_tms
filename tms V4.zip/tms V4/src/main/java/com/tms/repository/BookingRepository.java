package com.tms.repository;

import java.util.Optional;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tms.dto.BookingDto;
import com.tms.entity.Booking;



//repository interface extends JpaRepository to perform CRUD operations on the entity
@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
	@Query(value = "SELECT * FROM booking a WHERE rute_id = ?1 AND vehicle_id = ?2", nativeQuery = true)
	public Booking getBookingById(Long ruteId, Long vehicleId);
	
	
	//public Booking findByRoute_Id;
}
