package com.tms.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.tms.entity.Vehicle;
 //Repository interface for managing Vehicle entities using Spring Data JPA.
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
 
	Boolean findByIsAvailable(Boolean isAvailable);
 
}
