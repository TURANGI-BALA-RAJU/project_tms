
package com.tms.repository;
 
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;

import com.tms.entity.User;

@Repository

public interface UserRepository extends JpaRepository<User, Long> {

	@Query(value = "select * FROM users a where booking_id = ?1",nativeQuery = true)

	public  User getBookingById(Long id);

	User findByUserName(String username);
 
	  @Query(value = "select * FROM login_user a where role_id = ?1",nativeQuery = true)

		public User getRolesById(Long id);


}
