package com.tms.service;



import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tms.dto.BookingDto;
import com.tms.dto.RoleDto;
import com.tms.entity.Booking;
import com.tms.entity.Role;
import com.tms.entity.User;
import com.tms.exception.RoleNotFound;
import com.tms.exception.UserNotFoundException;
import com.tms.repository.RoleRepository;



@Service
public class RoleService {
	@Autowired
	RoleRepository roleRepo;
	
	@Autowired
	private ModelMapper modelMapper;
//	User user = userrepo.findById(id).orElseThrow(
//			()->new UserNotFoundException("User Not Found"+id));
//	return mapToDto(user);
	public RoleDto getRoleById(Long id) throws RoleNotFound {
		Role role = roleRepo.findById(id).orElseThrow(
				()->new RoleNotFound("Role Not found"));
		return mapToDto(role);
	}

	public List<RoleDto> getRoleFromDatabase() {
		return roleRepo.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());
		
	}

	public RoleDto createrole(RoleDto role) {
		return mapToDto(roleRepo.save(mapToEntity(role)));
	}

	

	public List<RoleDto> listAll() {

		List<RoleDto> roles = roleRepo.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());
		
	
		return roles;
	}

	public Map<String, Boolean> deleteRole(Long roleId) {
		roleRepo.deleteById(roleId);
		Map<String, Boolean> response = new HashMap();
		response.put("Roles has been deleted", Boolean.TRUE);
		return response;
	}
	
	public RoleDto mapToDto(Role role)
	{
		return modelMapper.map(role, RoleDto.class);
	}
	public Role mapToEntity(RoleDto roleDto)
	{
		return modelMapper.map(roleDto,Role.class);
	}
}
