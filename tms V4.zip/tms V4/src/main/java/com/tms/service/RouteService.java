package com.tms.service;


import java.util.HashMap;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tms.dao.RouteDao;
import com.tms.dto.InvoiceDto;
import com.tms.dto.RouteDto;
import com.tms.entity.Invoice;
import com.tms.entity.Route;
import com.tms.repository.RouteRepository;
 

//RouteService.java
@Service
public class RouteService implements RouteDao{
 
@Autowired
private RouteRepository routeRepository;
@Autowired
private ModelMapper modelMapper;

public RouteDto mapToDto(Route route)
{
	return modelMapper.map(route, RouteDto.class);
}


public Route mapToEntity(RouteDto routeDto)
{
	return modelMapper.map(routeDto, Route.class);
}
public RouteDto addRoute(RouteDto route) {
     return mapToDto(routeRepository.save(mapToEntity(route)));
}
 
public boolean removeRoute(Long routeId) {
     if (routeRepository.existsById(routeId)) {
         routeRepository.deleteById(routeId);
         return true;
     }
     return false;
}
 
public RouteDto getRouteById(Long routeId) {
     return mapToDto(routeRepository.findById(routeId).get());
}
public List<RouteDto> getAllRoutes() {
	return routeRepository.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());
}
}
 