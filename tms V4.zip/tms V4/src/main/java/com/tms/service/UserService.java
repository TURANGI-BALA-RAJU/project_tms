
package com.tms.service;
 
 
import java.util.ArrayList;



import java.util.List;


import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.tms.dao.UserDao;
import com.tms.dto.UserDto;
import com.tms.entity.User;
import com.tms.exception.UserNotFoundException;
import com.tms.repository.UserRepository;

 
//implements the service layer

@Service

public class UserService implements UserDao{

	@Autowired

	UserRepository userrepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public UserDto mapToDto(User user)
	{
		return modelMapper.map(user, UserDto.class);
	}
	
	
	public User mapToEntity(UserDto user)
	{
		return modelMapper.map(user, User.class);
	}

	public UserDto getUser(Long id) {

		User user = userrepo.findById(id).get();

		return mapToDto(user);

	}


	public List<UserDto> getAllUserFromDatabase() {
    
		return userrepo.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());
//		List<UserDto> al=new ArrayList<>();
//		List<User> findAll = userrepo.findAll();
//		for(User user:findAll)
//		{
//			al.add(mapToDto(user));
//		}
		
		

	}

	public UserDto createUser(UserDto oldUser) {

		return mapToDto(userrepo.save(mapToEntity(oldUser)));

	}

	public List<UserDto> listAll() {

		

		//System.out.println(users);

		return  userrepo.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());

	}

	public String deleteUser(Long userId) {
      
		userrepo.findById(userId).orElseThrow(
		()->new UserNotFoundException("User Not Found"+userId));
		userrepo.deleteById(userId);

		return "Deleted Successfully";

	}

	public UserDto getUserById(Long id) {

		User user = userrepo.findById(id).orElseThrow(
				()->new UserNotFoundException("User Not Found"+id));
		return mapToDto(user);

	}


	

}
