package com.tms.service;

 
 
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tms.dao.VehicleDao;
import com.tms.dto.UserDto;
import com.tms.dto.VehicleDto;
import com.tms.entity.User;
import com.tms.entity.Vehicle;
import com.tms.exception.UserNotFoundException;
import com.tms.exception.VehicleNotFoundException;
import com.tms.repository.VehicleRepository;
 
//Indicates that the class is a Spring service bean.
@Service
public class VehicleService implements VehicleDao{
	@Autowired
	VehicleRepository vehiclerepo;
	
	@Autowired
	// A library used for mapping between objects. It helps in converting one object to another.
	private ModelMapper modelMapper;
	
	// Method to map Entity to DTO
	public VehicleDto mapToDto(Vehicle vehicle)
	{
		return modelMapper.map(vehicle, VehicleDto.class);
	}
	
	// Method to map DTO to Entity
	public Vehicle mapToEntity(VehicleDto vehicleDto)
	{
		return modelMapper.map(vehicleDto, Vehicle.class);
	}
	// Retrieve a vehicle by ID
	public VehicleDto getVehicle(Long id) {
		Vehicle vehicle = vehiclerepo.findById(id).get();
		return mapToDto(vehicle);
	}
 
	

	// Retrieve all vehicles from the database
	public List<VehicleDto> getAllVehicleFromDatabase() {
		return vehiclerepo.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());
	}
	// Create a new vehicle
	public VehicleDto createVehicle(VehicleDto oldVehicle) {
		return mapToDto(vehiclerepo.save(mapToEntity(oldVehicle)));
	}
	// Check if a vehicle with the specified availability exists
	public Boolean isAvailable(Boolean isAvailable) {
		return vehiclerepo.findByIsAvailable(isAvailable) != null;
	}
	
	// Delete a vehicle by ID
	public Map<String, Boolean> deleteVehicle(Long vehicleId) {
		vehiclerepo.deleteById(vehicleId);
		Map<String, Boolean> response = new HashMap();
		response.put("vehicle has been deleted", Boolean.TRUE);
		return response;
	}
	// Retrieve a vehicle by ID, throw exception if not found
	public VehicleDto getVehicleById(Long id) {
		Vehicle vehicle = vehiclerepo.findById(id).orElseThrow(()->new VehicleNotFoundException("Vehicle  is not found"));
		return mapToDto(vehicle);
	}


	
}