package com.tms.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tms.dao.BookingDao;
import com.tms.dto.BookingDto;
import com.tms.dto.UserDto;
import com.tms.entity.Booking;
import com.tms.entity.Role;
import com.tms.entity.User;
import com.tms.repository.BookingRepository;
import com.tms.repository.InvoiceRepository;

@Service
public class BookingService implements BookingDao{
	@Autowired
	private ModelMapper modelMapper;
	
	public BookingDto mapToDto(Booking booking)
	{
		return modelMapper.map(booking, BookingDto.class);
	}
	
	
	public Booking mapToEntity(BookingDto bookingDto)
	{
		return modelMapper.map(bookingDto, Booking.class);
	}

	@Autowired

    private BookingRepository bookingRepository;

	public BookingDto getBoking(Long id) {
		Booking booking = bookingRepository.getBookingById(id, id);
		return mapToDto(booking);
	}
	

	public List<BookingDto> getBookingFromDatabase() {
		return bookingRepository.findAll().stream().map(x->mapToDto(x)).collect(Collectors.toList());
		
	}
	public void createBooking(BookingDto booking) {
		 mapToDto(bookingRepository.save(mapToEntity(booking)));
	}
	
	
	
	
	

}
