package com.tms.service;


import java.util.HashMap;


 
import java.util.List;

import java.util.Map;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.tms.dto.BookingDto;
import com.tms.dto.InvoiceDto;
import com.tms.dto.RouteDto;
import com.tms.entity.Booking;
import com.tms.entity.Invoice;
import com.tms.entity.Route;
import com.tms.repository.InvoiceRepository;



//service class contains the business logic to perform CRUD operations

@Service

public class InvoiceService {

    private final double COST_PER_KM = 10.0;

    @Autowired

    private RouteService routeService;

    @Autowired
    private InvoiceRepository invoiceRepository;
    @Autowired
	private ModelMapper modelMapper;
	
	public InvoiceDto mapToDto(Invoice invoice)
	{
		return modelMapper.map(invoice, InvoiceDto.class);
	}
	
	
	public Invoice mapToEntity(InvoiceDto invoiceDto)
	{
		return modelMapper.map(invoiceDto, Invoice.class);
	}
    public InvoiceDto generateInvoice(Long routeId) {

       RouteDto optionalRoute = routeService.getRouteById(routeId);

        if (optionalRoute!=null) {

            Route route = routeService.mapToEntity(optionalRoute);

            double amount = route.getDistance() * COST_PER_KM;

            Invoice invoice = new Invoice();

          

            invoice.setAmount(amount);

            invoice.setRoute(route);

            return mapToDto(invoiceRepository.save(invoice));

        }

        return null;

    }

    public InvoiceDto getInvoiceById(Long invoiceId) {

        return mapToDto(invoiceRepository.findById(invoiceId).orElse(null));

    }

}
 
