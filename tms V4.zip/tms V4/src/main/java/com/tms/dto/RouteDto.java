package com.tms.dto;

import jakarta.persistence.Column;


public class RouteDto {
	@Column (name="ID")
	private Long id;
	
	@Column (name="Source")
	private String source;
	
	@Column (name="Destination")
	private String destination;
	
	@Column (name="Distance")
	private Integer distance;
 
	public Long getId() {
		return id;
	}
 
	public void setId(Long id) {
		this.id = id;
	}
 
	public String getSource() {
		return source;
	}
 
	public void setSource(String source) {
		this.source = source;
	}
 
	public String getDestination() {
		return destination;
	}
 
	public void setDestination(String destination) {
		this.destination = destination;
	}
 
	public Integer getDistance() {
		return distance;
	}
 
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	
 
	public RouteDto() {
		super();
	}
 
	@Override
	public String toString() {
		return "Route [id=" + id + ", source=" + source + ", destination=" + destination + ", distance=" + distance
				+ "]";
	}
 
	public RouteDto(Long id, String source, String destination, Integer distance) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
	}
 
}
