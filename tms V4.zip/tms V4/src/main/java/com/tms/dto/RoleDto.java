package com.tms.dto;

public class RoleDto {
	private Long id;
	private String name;
	private String discription;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public RoleDto(Long id, String name, String discription) {
		super();
		this.id = id;
		this.name = name;
		this.discription = discription;
	}
	public RoleDto() {
		super();
	}
	@Override
	public String toString() {
		return "RoleDto [id=" + id + ", name=" + name + ", discription=" + discription + "]";
	}
	
}
