package com.tms.dto;



public class VehicleDto {
	private Long id;
	

	
	private Boolean isAvailable;
	
	private String name;
	
	private String number;

	public boolean getIsAvailable() {
		return this.isAvailable;
	}

	public void setAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public VehicleDto(Boolean isAvailable, Long id, String name, String number) {
		super();

		this.isAvailable = isAvailable;
		this.id = id;
		this.name = name;
		this.number = number;
	}

	public VehicleDto() {
		super();
	}

	

}
