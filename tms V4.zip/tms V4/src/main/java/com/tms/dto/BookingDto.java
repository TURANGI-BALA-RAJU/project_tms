package com.tms.dto;

import com.tms.entity.Booking;
import com.tms.entity.Route;

import com.tms.entity.Vehicle;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;



public class BookingDto {
	private Long booking_id;
	@Column(name = "route_id")
	private RouteDto route;
	@Column(name = "vehicle_id")
	private VehicleDto vehicle;

	public Long getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(Long booking_id) {
		this.booking_id = booking_id;
	}

	public RouteDto getRoute() {
		return route;
	}

	public void setRoute(RouteDto route) {
		this.route = route;
	}

	public VehicleDto getVehicle() {
		return vehicle;
	}

	public void setVehicle(VehicleDto vehicle) {
		this.vehicle = vehicle;
	}

	public BookingDto(Long booking_id, RouteDto route, VehicleDto vehicle) {
		super();
		this.booking_id = booking_id;
		this.route = route;
		this.vehicle = vehicle;
	}

	public BookingDto() {
		super();
	}

	@Override
	public String toString() {
		return "Booking [booking_id=" + booking_id + ", route=" + route + ", vehicle=" + vehicle + "]";
	}

}
