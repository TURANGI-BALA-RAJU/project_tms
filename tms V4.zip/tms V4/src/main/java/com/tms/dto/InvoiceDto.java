package com.tms.dto;



import jakarta.persistence.JoinColumn;

import jakarta.validation.constraints.NotNull;

public class InvoiceDto {
	 private Long id;
     //it should contain some value
	@NotNull(message="Not to be null")
    private double amount;
	

    
    @JoinColumn(name = "route_id")
    private RouteDto route;

	public Long getId() {

		return id;

	}

	public void setId(Long id) {

		this.id = id;

	}

	public double getAmount() {

		return amount;

	}

	public void setAmount(double amount) {

		this.amount = amount;

	}

	

	public RouteDto getRoute() {

		return route;

	}

	public void setRoute(RouteDto route) {

		this.route = route;

	}

	public InvoiceDto(Long id,  double amount,RouteDto route) {

		super();

		this.id = id;

		this.amount = amount;

		

		this.route = route;

	}

	public InvoiceDto() {

		super();

	}

	@Override

	public String toString() {

		return "Invoice [id=" + id + ", amount=" + amount  + ", route=" + route + "]";

	}


}
