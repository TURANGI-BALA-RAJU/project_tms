package com.tms.dto;

import com.tms.entity.Booking;
import com.tms.entity.Role;

import jakarta.persistence.JoinColumn;

public class UserDto {
	
	private String details;
	@JoinColumn(name = "role_id")
	private RoleDto role;
	
	private boolean isActive;
	
	private BookingDto booking;

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public RoleDto getRole() {
		return role;
	}

	public void setRole(RoleDto role) {
		this.role = role;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public BookingDto getBooking() {
		return booking;
	}

	public void setBooking(BookingDto booking) {
		this.booking = booking;
	}

	public UserDto(String details, RoleDto role, boolean isActive, BookingDto booking) {
		super();
		this.details = details;
		this.role = role;
		this.isActive = isActive;
		this.booking = booking;
	}
	
	
    public UserDto()
    {
    	super();
    }
}
