package com.tms.dao;

import java.util.List;

import com.tms.dto.RouteDto;

public interface RouteDao {
	public boolean removeRoute(Long routeId);
	public RouteDto getRouteById(Long routeId);
	public List<RouteDto> getAllRoutes();
}
