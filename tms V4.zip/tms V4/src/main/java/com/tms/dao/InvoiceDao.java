package com.tms.dao;

import com.tms.entity.Invoice;

public interface InvoiceDao {
	public Invoice generateInvoice(Long routeId);
}
