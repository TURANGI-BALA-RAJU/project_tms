package com.tms.dao;

import java.util.List;
import java.util.Map;

import com.tms.dto.VehicleDto;
import com.tms.entity.Vehicle;

public interface VehicleDao {
	//Retrieve a vehicle DTO by its ID.
	public VehicleDto getVehicle(Long id);
	//Retrieve a list of all vehicle DTOs from the database.
	public List<VehicleDto> getAllVehicleFromDatabase();
	//Create a new vehicle based on the provided VehicleDto.
	public VehicleDto createVehicle(VehicleDto vehicle);
	//Check if a vehicle with the specified availability status exists in the database.
	public Boolean isAvailable(Boolean isAvailable);
	//Delete a vehicle from the database based on its ID.
	public Map<String, Boolean> deleteVehicle(Long vehicleId);
	//Retrieve a vehicle DTO by its ID, throwing an exception if not found.
	public VehicleDto getVehicleById(Long id);
}
