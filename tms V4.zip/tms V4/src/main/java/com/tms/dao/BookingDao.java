package com.tms.dao;

import java.util.List;

import com.tms.dto.BookingDto;

public interface BookingDao {
	public BookingDto getBoking(Long id);
	public List<BookingDto> getBookingFromDatabase();
	public void createBooking(BookingDto booking);
}
