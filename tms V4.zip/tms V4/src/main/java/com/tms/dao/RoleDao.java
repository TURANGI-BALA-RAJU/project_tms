package com.tms.dao;

import java.util.List;
import java.util.Map;

import com.tms.dto.RoleDto;

public interface RoleDao {
	public List<RoleDto> getRoleFromDatabase();
	public RoleDto createrole(RoleDto role);
	public List<RoleDto> listAll();
	public Map<String, Boolean> deleteRole(Long roleId);
}
