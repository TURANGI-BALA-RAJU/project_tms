package com.tms.dao;

import java.util.List;

import com.tms.dto.UserDto;
import com.tms.entity.User;

public interface UserDao {
	public UserDto getUser(Long id);
	public List<UserDto> getAllUserFromDatabase();
	public UserDto createUser(UserDto user);
	public List<UserDto> listAll();
	public String deleteUser(Long userId);
	public UserDto getUserById(Long id);
}
