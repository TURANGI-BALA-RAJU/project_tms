package com.tms.exception;
import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.ResponseStatus;

//to provide a HTTP status code returned by a particular end point

@ResponseStatus(HttpStatus.NOT_FOUND)

//This exception is annotated with @ResponseStatus to indicate that, when thrown,

public class InvoiceNotFoundException extends RuntimeException{

     public InvoiceNotFoundException(String message) {

    // Call the constructor of the superclass (RuntimeException) with the provided message.

     super(message);

}

}

