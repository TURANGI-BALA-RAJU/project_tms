package com.tms.exception;

public class VehicleNotFoundException extends RuntimeException{
	public VehicleNotFoundException(String message) {
		// Call the constructor of the superclass (RuntimeException) with the provided message.
		  super(message);
		    }
}

