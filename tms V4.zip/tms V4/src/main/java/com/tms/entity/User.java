
package com.tms.entity;
 
import jakarta.persistence.CascadeType;

import jakarta.persistence.Entity;
 
import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.JoinColumn;

import jakarta.persistence.ManyToOne;

import jakarta.persistence.OneToOne;

import jakarta.persistence.Table;

import jakarta.validation.constraints.NotEmpty;

import jakarta.validation.constraints.NotNull;
 
@Entity // it is an entity class

@Table(name = "users") // used to specify in database

public class User {

	@Id // represent the Primary key

	@GeneratedValue(strategy = GenerationType.AUTO) // Generated id

	@NotEmpty(message = "Not to be Empty")

	private String details;

	@ManyToOne(cascade = CascadeType.ALL)

	@JoinColumn(name = "role_id")

	private Role role;

	private boolean isActive;

	@OneToOne(cascade = CascadeType.ALL)

	@JoinColumn(name = "booking_id")

	private Booking booking;

	public String getDetails() {

		return details;

	}

	public void setDetails(String details) {

		this.details = details;

	}

	public Role getRole() {

		return role;

	}

	public void setRole(Role role) {

		this.role = role;

	}

	public boolean isActive() {

		return isActive;

	}

	public void setActive(boolean isActive) {

		this.isActive = isActive;

	}

	public Booking getBooking() {

		return booking;

	}

	public void setBooking(Booking booking) {

		this.booking = booking;

	}

	public Long getId() {

		return id;

	}

	public void setId(Long id) {

		this.id = id;

	}

	public String getUserName() {

		return userName;

	}

	public void setUserName(String userName) {

		this.userName = userName;

	}

	public String getPassword() {

		return password;

	}

	public void setPassword(String password) {

		this.password = password;

	}

	private Long id;

	@NotNull(message="username not to be null")

	private String userName;

	@NotNull(message="password not to be null")

	private String password;

	public User(Long id,  String userName,String password, String details, Role role, boolean isActive, Booking booking) {

		super();

		this.id = id;

		this.userName = userName;

		this.password = password;

		this.details = details;

		this.role = role;

		this.isActive = isActive;

		this.booking = booking;

	}

	@Override

	public String toString() {

		return "User [id=" + id + ", userName=" + userName + ", password=" + password + ", details=" + details

				+ ", role=" + role + ", isActive=" + isActive + ", booking=" + booking + "]";

	}

	public User() {

		super();

	}

 
}	
