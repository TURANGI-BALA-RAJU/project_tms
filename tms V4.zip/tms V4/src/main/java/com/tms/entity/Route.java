package com.tms.entity;


 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
 
@Entity
@Table(name = "Route")
public class Route {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column (name="ID")
	private Long id;
	@NotNull(message="Not to be empty")
	@Column (name="Source")
	private String source;
	@NotNull(message="Not to be empty")
	@Column (name="Destination")
	private String destination;
	@NotNull(message="Not to be empty")
	@Column (name="Distance")
	private Integer distance;
 
	public Long getId() {
		return id;
	}
 
	public void setId(Long id) {
		this.id = id;
	}
 
	public String getSource() {
		return source;
	}
 
	public void setSource(String source) {
		this.source = source;
	}
 
	public String getDestination() {
		return destination;
	}
 
	public void setDestination(String destination) {
		this.destination = destination;
	}
 
	public Integer getDistance() {
		return distance;
	}
 
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	
 
	public Route() {
		super();
	}
 
	@Override
	public String toString() {
		return "Route [id=" + id + ", source=" + source + ", destination=" + destination + ", distance=" + distance
				+ "]";
	}
 
	public Route(Long id, String source, String destination, Integer distance) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
	}
 
}
