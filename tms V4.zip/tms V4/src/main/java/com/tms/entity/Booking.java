package com.tms.entity;

import java.util.Set;

import com.tms.dto.VehicleDto;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Booking")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long booking_id;

	public Long getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(Long booking_id) {
		this.booking_id = booking_id;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	// one to many relationship
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Booking.class)
	@JoinColumn(name = "route_id")
	private Route route;
	@OneToOne(cascade = CascadeType.ALL, targetEntity = Booking.class)
	@JoinColumn(name = "vehicle_id")
	private Vehicle vehicle;

	public Booking(Long booking_id, Route route, Vehicle vehicle) {
		super();
		this.booking_id = booking_id;
		this.route = route;
		this.vehicle = vehicle;
	}

	public Booking() {
		super();
	}

	@Override
	public String toString() {
		return "Booking [booking_id=" + booking_id + ", route=" + route + ", vehicle=" + vehicle + "]";
	}

}
