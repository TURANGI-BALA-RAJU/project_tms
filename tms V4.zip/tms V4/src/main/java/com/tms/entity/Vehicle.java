package com.tms.entity;


 
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
 
 
@Entity
@Table(name="Vehicle")
public class Vehicle {
	// Primary key ID for the vehicle
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(name="id")
   private Long id;
	// Indicates whether the vehicle is available
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@Column(name="isAvailble")
	private Boolean isAvailable;
	@NotNull(message="not to be null")
	@Column(name="name")
   private String name;
	// Number associated with the vehicle
	@NotNull(message="not to be null")
	@Column(name="number")
   private String number;
	// Getter and setter methods for the fields
//Getter for the availability status of the vehicle.
	//Setter for the availability status of the vehicle.
public boolean getIsAvailable() {
	return this.isAvailable ;
}
public void setAvailable(Boolean isAvailable) {
	this.isAvailable = isAvailable;
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
//Constructors for creating instances of the Vehicle class
//Parameterized constructor for creating a new instance of the Vehicle class.
public Vehicle(Boolean isAvailable, Long id, String name, String number) {
	super();
	
	this.isAvailable = isAvailable;
	this.id = id;
	this.name = name;
	this.number = number;
}
//Default constructor for creating an empty instance of the Vehicle class.
public Vehicle() {
	super();
}
//Override toString() method for better string representation
// Overrides the default toString() method to provide a customized string representation of the object.
@Override
public String toString() {
	return "Vehicle [isAvailable=" + isAvailable + ", id=" + id + ", name=" + name + ", number=" + number + "]";
}
   
   
 
}
 
 
