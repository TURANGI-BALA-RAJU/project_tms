package com.tms.entity;

import org.springframework.beans.factory.annotation.Autowired;



import jakarta.persistence.Entity;


import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.JoinColumn;

import jakarta.persistence.OneToOne;

import jakarta.persistence.Table;

import jakarta.validation.constraints.NotNull;

//map it to a database table

@Entity

@Table(name = "Invoice")

public class Invoice {
	
	//specifies the primary key of an entity     
	@Id           
	@GeneratedValue(strategy = GenerationType.AUTO)
	    private Long id;
	     //it should contain some value
		@NotNull(message="Not to be null")
	    private double amount;
		

	    @OneToOne
	    @JoinColumn(name = "route_id")
	    private Route route;
 
		public Long getId() {

			return id;

		}
 
		public void setId(Long id) {

			this.id = id;

		}
 
		public double getAmount() {

			return amount;

		}
 
		public void setAmount(double amount) {

			this.amount = amount;

		}
 
		
 
		public Route getRoute() {

			return route;

		}
 
		public void setRoute(Route route) {

			this.route = route;

		}
 
		public Invoice(Long id,  double amount,

				Route route) {

			super();

			this.id = id;

			this.amount = amount;

			

			this.route = route;

		}
 
		public Invoice() {

			super();

		}
 
		@Override

		public String toString() {

			return "Invoice [id=" + id + ", amount=" + amount  + ", route=" + route + "]";

		}


	}