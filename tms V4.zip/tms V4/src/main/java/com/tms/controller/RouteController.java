package com.tms.controller;


import java.util.Optional;
 
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tms.dto.RouteDto;
import com.tms.entity.Route;
import com.tms.exception.RouteNotFoundException;
import com.tms.service.RouteService;
 

 
// RouteController.java
@RestController
@RequestMapping("/api")
public class RouteController {
 
    @Autowired
    private RouteService routeService;
    Logger logger = LogManager.getLogger(RouteController.class);
    @PostMapping("/add/route")
    public String addRoute(@RequestBody RouteDto route) {
        RouteDto addedRoute = routeService.addRoute(route);
        return "route Added successfully";
    }
 
    @DeleteMapping("/routes/remove/{routeId}")
    public ResponseEntity<String> removeRoute(@PathVariable Long routeId) {
    	logger.info("removing route from user list");
        boolean success = routeService.removeRoute(routeId);
        if (success) {
            return new ResponseEntity<>("Route removed successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Route not found", HttpStatus.NOT_FOUND);
        }
    }
 
    @GetMapping("/routes/{routeId}")
    public RouteDto getRoute(@PathVariable Long routeId)throws RouteNotFoundException {
    	RouteDto route=routeService.getRouteById(routeId);;
    	if(route!=null) {
  
        return route;
    	}else {
    		throw new RouteNotFoundException("Route not found "+routeId);
    	}
}
}
 
