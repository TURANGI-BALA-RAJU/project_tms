package com.tms.controller;



import org.apache.logging.log4j.Logger;

 
import java.util.List;

import java.util.Map;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.http.MediaType;
 
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
 
import org.springframework.web.bind.annotation.PathVariable;
 
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;
 
import org.springframework.web.bind.annotation.RequestMapping;
 
import org.springframework.web.bind.annotation.RestController;

import com.tms.dto.VehicleDto;
import com.tms.entity.Vehicle;
import com.tms.exception.VehicleNotFoundException;
import com.tms.service.VehicleService;

import jakarta.validation.Valid;
 
import org.apache.logging.log4j.LogManager;
 
@RestController
//It map the HTTP request to handle methods of MVC and Rest controller
@RequestMapping("/api")
public class VehicleController {
	
	@Autowired
	VehicleService service;
	Logger logger = LogManager.getLogger(VehicleController.class);
	//@GetMapping("/vehicles")
	@GetMapping(path="/all/vehicles",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<VehicleDto> viewVehicleList() {
		logger.info("All Vechile List");
		 // Retrieve and return a list of all vehicles
		List<VehicleDto> listvehicles =service.getAllVehicleFromDatabase();
		return listvehicles;

	}

	//It map http get methods
	 // Get mapping for retrieving a specific vehicle by ID
	@GetMapping("/find/vehicle/{id}")
	public VehicleDto getVehicle(@PathVariable Long id) {
		logger.info("find Vehicle  Start");
		// Retrieve and return a specific vehicle by ID
		VehicleDto optionalVehicle=service.getVehicle(id);
		return optionalVehicle;

	}
	// Get mapping for checking the availability of a specific vehicle by ID
	@GetMapping("/vehicle/available/{id}")
	public String  isAvailable(@Valid @PathVariable Long id)  {
		logger.info("find Vehicle  Start");
		// Check if a specific vehicle is available by ID
		VehicleDto vehicleAvailable = service.getVehicleById(id);//.getIsAvailable();
		System.out.println(vehicleAvailable.getIsAvailable());
		if(vehicleAvailable.getIsAvailable()){

			return "Vehicle is Available";

		}
		else {

		return "Vehicle is not Available";
		}
	}

	//It map the http POST methods
	// Post mapping for adding a new vehicle
	@PostMapping("/add/vehicle")
	public VehicleDto createVechicle( @Valid @RequestBody VehicleDto newVehicle) {
		logger.info("create vehicle Start");
		// Create and return a new vehicle
		return service.createVehicle(newVehicle);

	}


	// Put mapping for updating the status of a vehicle by ID
	@PutMapping("/update/vehicles/{id}")
	public void updateStatus(@Valid @RequestBody VehicleDto newVehicle ,@PathVariable Long id  ) {
		// Retrieve the existing vehicle by ID
		VehicleDto oldVehicle = service.getVehicleById(id);
		// Update the availability status of the existing vehicle
		oldVehicle.setAvailable(newVehicle.getIsAvailable());
		//Save the updated vehicle
		service.createVehicle(oldVehicle);


	}

}

