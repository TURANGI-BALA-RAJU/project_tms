package com.tms.controller;

import java.util.Optional;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tms.dto.BookingDto;
import com.tms.dto.RouteDto;
import com.tms.entity.Booking;

import com.tms.entity.Role;
import com.tms.entity.Route;
import com.tms.entity.User;
import com.tms.exception.BookingNotFoundException;

import com.tms.service.BookingService;
import com.tms.service.RouteService;
import com.tms.service.UserService;
import com.tms.service.VehicleService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class BookingController {
	@Autowired
	private UserService userservice;
	
	@Autowired
	 private BookingService bookingService;
	@Autowired
	private VehicleService vehicleService;
	@Autowired
	private RouteService routeService;
	
	Logger logger = LogManager.getLogger(BookingController.class);
	@PostMapping("/booking/vehicle/{v_id}/route/{route_id}")
	
	public void createBooking( @Valid @PathVariable Long route_id,@PathVariable Long v_id,@RequestBody BookingDto newBooking) {
		BookingDto book=newBooking;
		RouteDto route = routeService.getRouteById(route_id);
		
		book.setRoute(route);
		book.setVehicle(vehicleService.getVehicleById(v_id));
		
		logger.info("create booking ");
		bookingService.createBooking(newBooking);
		
		
	}
	@GetMapping("/booking/{id}")
	public BookingDto getBooking(@Valid @PathVariable Long id)throws BookingNotFoundException {
		BookingDto  booking=bookingService.getBoking(id);
		
			return booking;
		
		
	}
  
}
