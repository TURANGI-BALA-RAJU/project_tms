
package com.tms.controller;
 
 
//communication between model and view
 
import java.util.List;
 


import java.util.Optional;
 
import org.apache.logging.log4j.LogManager;

import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.http.MediaType;
 
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
 
import org.springframework.web.bind.annotation.PathVariable;
 
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;
 
import org.springframework.web.bind.annotation.RequestMapping;
 
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.client.ResourceAccessException;

import com.tms.dto.BookingDto;
import com.tms.dto.RoleDto;
import com.tms.dto.RouteDto;
import com.tms.dto.UserDto;
import com.tms.entity.Booking;

import com.tms.entity.Role;

import com.tms.entity.Route;

import com.tms.entity.User;

import com.tms.exception.RoleNotFound;

import com.tms.repository.UserRepository;

import com.tms.service.BookingService;

import com.tms.service.RoleService;

import com.tms.service.RouteService;

import com.tms.service.UserService;
 
import jakarta.validation.Valid;
 
import org.apache.logging.log4j.Logger;

//Define the controller class
 
 
@RestController

@RequestMapping("/api")// specific request path onto a controller

public class UserController {

	// Initialize a logger

	Logger logger = LogManager.getLogger(UserController.class);

	@Autowired RoleService roleService;

	@Autowired

	RouteService routeService;

	@Autowired

	UserRepository userrepo;

	// Autowire the UserService or connecting two objects

	@Autowired

	UserService userService;

	@Autowired

	BookingService bookingService;

	//@GetMapping to fetch the details in the url

	@GetMapping(path="/users",produces= {MediaType.APPLICATION_JSON_VALUE})

	public List<UserDto>viewUserList() throws RoleNotFound {

		logger.info("viewing from user list");

		List<UserDto> listusers =userService.listAll();

		if(listusers.isEmpty()) {

			throw new RoleNotFound("Users not in the list ");

		}else{

		logger.info("End of user list");

		return listusers;

		}

	}

	@GetMapping("/users/all/routes")

	public List<RouteDto> findAllRoutes(){

		return routeService.getAllRoutes();

	}

	//It used to fetch the details

	@GetMapping("/users/{id}")

	public UserDto findByUser(@PathVariable Long id)  {

		logger.info("user is found");

      UserDto user = userService.getUser(id);

      

		return user;

	}	

//Gives the input request to the web page

	@PostMapping("/users/booking/{b_id}/role/{role_id}")

	public void createUser( @Valid @RequestBody UserDto newUser,@PathVariable Long b_id,@PathVariable Long role_id) throws RoleNotFound {

		BookingDto book=bookingService.getBoking(b_id);

		logger.info("new user is created");

		RoleDto role = roleService.getRoleById(role_id);

		UserDto user=newUser;

		user.setRole(role);

		user.setBooking(book);

		userService.createUser(newUser);

	}

	@PutMapping("/users/{id}")

	public UserDto updateStatus(@Valid @RequestBody UserDto newUser ,@PathVariable Long id) {

//		User user1=new User();

//		user1.getBooking()

		UserDto oldUser = userService.getUserById(id);

		oldUser.setActive(newUser.isActive());

		 UserDto user=userService.createUser(oldUser);

		 return user;

	}




}
 